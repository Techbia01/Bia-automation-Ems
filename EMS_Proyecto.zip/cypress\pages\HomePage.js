// cypress/pages/HomePage.js
class HomePage {
  // Selectores simples
  get facturasSection() { return 'Facturas'; }
  get resumenConsumoSection() { return 'Resumen de consumo'; }
}

export default HomePage;